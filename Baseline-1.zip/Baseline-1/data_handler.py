import json
import codecs
import pdb
import pandas as pd
"""
def get_data():
    tweets = []
    files = ['racism.json', 'neither.json', 'sexism.json']
    for file in files:
        with codecs.open('./tweet_data/' + file, 'r', encoding='utf-8') as f:
            data = f.readlines()
        for line in data:
            tweet_full = json.loads(line)
            tweets.append({
                'id': tweet_full['id'],
                'text': tweet_full['text'].lower(),
                'label': tweet_full['Annotation'],
                'name': tweet_full['user']['name'].split()[0]
                })

    #pdb.set_trace()
    return tweets
"""

def get_data():
    tweets = []
    train = pd.read_csv("D:/Swati/Gtech/Websearch/Project/labeledTrainData.csv",delimiter="\t",names=["tweet", "label", "labelValue"])
    train["label"].replace({"spam": "neutral","normal": "neutral"},inplace=True)
    for x in range(99994):
        i = 0

        t = train["tweet"][x]
        tweets.append({
                'tweet': t,
                'label': train["label"][x],
                'labelValue': train["labelValue"][x]
                })
        i +=1
    #pdb.set_trace()
    print(len(tweets))
    return tweets

if __name__=="__main__":
    tweets = get_data()
    males, females = {}, {}
    with open('./tweet_data/males.txt') as f:
        males = set([w.strip() for w in f.readlines()])
    with open('./tweet_data/females.txt') as f:
        females = set([w.strip() for w in f.readlines()])

    males_c, females_c, not_found = 0, 0, 0
    for t in tweets:
        if t['name'] in males:
            males_c += 1
        elif t['name'] in females:
            females_c += 1
        else:
            not_found += 1
    print(males_c, females_c, not_found)
    pdb.set_trace()
